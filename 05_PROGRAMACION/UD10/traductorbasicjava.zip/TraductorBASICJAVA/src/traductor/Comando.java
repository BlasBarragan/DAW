package traductor;

public enum Comando {
	PRINT, INPUT
}

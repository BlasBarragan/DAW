import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class UD5Ejercicio14 {
public static void main(String[] args)
    {
        Date ahora = new Date();
		System.out.println("Fecha y hora actual: " + ahora);		
		
		GregorianCalendar gc = new GregorianCalendar();
		gc.setTime(ahora);
		
		int maximoValorAnyo = gc.getActualMaximum(GregorianCalendar.YEAR);
		int maximoValorMes = gc.getActualMaximum(GregorianCalendar.MONTH);
		int maximoValorSemana = gc.getActualMaximum(GregorianCalendar.WEEK_OF_YEAR);
		int maximoValorDia = gc.getActualMaximum(GregorianCalendar.DATE);

		System.out.println("");
		System.out.println("Máximo valor soportado de año: " +maximoValorAnyo);
		System.out.println("Máximo valor soportado de mes: "+maximoValorMes);
		System.out.println("Máximo valor soportado de semana: "+maximoValorSemana);
		System.out.println("Máximo valor soportado de día del mes: "+maximoValorDia);
    }
}

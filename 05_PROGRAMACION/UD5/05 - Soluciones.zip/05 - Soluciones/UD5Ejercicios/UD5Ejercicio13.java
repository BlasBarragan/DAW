import java.util.Random;
import java.util.Scanner;

public class UD5Ejercicio13
{
    public static void main(String[] args) {
		final int numeroFinal = 13; // variable constante
	    int numero= 0;
	    int numerosGenerados = 0;
	    
	    Random rand = new Random();
	    
	    do {
	   	  numero = (int)(rand.nextDouble() * 20 + 1);
	   	  System.out.print(numero + " ");
	   	  numerosGenerados++;
	    } while(numero != numeroFinal);
	 
	    System.out.println("\nNúmeros generados: " + numerosGenerados);
    }
}

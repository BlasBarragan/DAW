import java.util.Scanner;

public class UD5Ejercicio01
{
    public static void main(String[] args)
    {
		final int TAMANYO = 6;
		
        short[] numeros = new short[TAMANYO];

        Scanner sc = new Scanner(System.in);

        // Guardo datos introducidos en array
        for (int i = 0; i < TAMANYO; i++)
        {
            System.out.print("Dame un número: ");
            numeros[i] = sc.nextShort();
        }

        // Muestro datos de array de forma inversa
        for (int i = 5; i >= 0; i--)
        {
            System.out.println(numeros[i] + " ");
        }
    }
}

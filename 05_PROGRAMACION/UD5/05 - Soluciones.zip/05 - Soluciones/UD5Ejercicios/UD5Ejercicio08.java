import java.util.Scanner;

public class UD5Ejercicio08
{
    public static void main(String[] args)
    {
        Scanner teclado = new Scanner(System.in);

        // Obtengo el nombre del usuario...
        System.out.print("Dame nombre: ");
        String nombre = teclado.nextLine();

        // Muestro la el nombre separado por espacios con charAt...
        for (int i = 0; i < nombre.length(); i++)
            System.out.print(nombre.charAt(i) + " ");
    }
}


/**
 * Barragán Román, Blas
 * Práctica Evaluable 1
 * Ejercicio 03 Totalmente
 * Lo siento señorita Ofelia
 */
import java.util.Scanner;

public class Ejercicio03 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		// Preguntamos cuantos empleados hay en la empresa
		System.out.println("Introduce el sueldo de empleado 1: ");
		// Definimos variables
		int sueldo = sc.nextInt();
		int empleados = 2;
		int maximo = sueldo;
		int minimo = sueldo;

		if (sueldo > 0) {
			for (;;) { // Bucle infinito que nos pedirá los sueldos
				// Registramos y comparamos los sueldos según se introducen
				System.out.println("Introduce el sueldo de empleado " + empleados++ + ": ");
				sueldo = sc.nextInt();
				if (sueldo == 0) {// Si marcamos 0 se termina el programa
					break;
				} else if (sueldo > maximo) { // Comparamos sueldos
					maximo = sueldo;
				} else if (sueldo < minimo) {
					minimo = sueldo;
				}
			}
			// Imprimimos resultado
			System.out.println("Sueldo máximo: " + maximo + "€");
			System.out.println("Sueldo mínimo: " + minimo + "€");
		} else {// Imprimimos mensaje por no haber empleados y termina programa
			System.out.println("No hay empleados");
		}
		sc.close();
	}
}

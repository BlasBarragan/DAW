/**
 * Barragán Román, Blas
 * Práctica Evaluable 1
 * Ejercicio 01 Totalmente
 * Estadistica de alumnos del Profesor Bacterio
 */
import java.util.Scanner;

public class Ejercicio01 
{
	public static void main(String[] args) 
	{
		//Definimos variables para contar las notas
		int brillantes = 0;
		int aprobados = 0;
		int condicionados = 0;
		int suspensos = 0;
		int cazurros = 0;
		// Definimos variable para calcular la calificación
		int nota;
				
		Scanner sc = new Scanner(System.in);
		// Se realizan tantas consultas como alumnos (10 alumnos)
		for (int i=0; i<10; i++) 
		{
			System.out.println("Introduzca la nota (número entero) del alumno: ");
			nota = sc.nextInt();
			// Se compara la nota introducida con las calificaciones disponibles
			// y se aumenta el resultado correspondiente
			if (nota >= 9 && nota<=10) {
				brillantes ++;
			}else if (nota >= 5 && nota <9){
				aprobados = aprobados +1;
			}else if (nota >=4 && nota <5){
				condicionados = condicionados +1;
			}else if (nota <4 && nota >0){
				suspensos = suspensos +1;
			}else if (nota == 0){
				cazurros = cazurros +1;
			}else { // Si se introduce un entero <0 o >10, imprimimos un error sin afectar a la condición
				System.out.println("¡¡ERROR!! Espabila Bacterio que no tenemos todo el dia!");
				i--;
			}
		}
		// Se muestra el resultado final por pantalla
		System.out.println("Los resultados de la evaluación son: ");
		System.out.println(brillantes + " alumno/s brillantes");
		System.out.println(aprobados + " alumno/s aprovados");
		System.out.println(condicionados + " alumno/s condicionados");
		System.out.println(suspensos + " alumno/s suspensos");
		System.out.println(cazurros + " alumno/s cazurros");
		sc.close();
	}
}

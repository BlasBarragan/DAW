package barajas;

enum Palo{OROS, COPAS, ESPADAS, BASTOS};

/*
public class Palos {
	
	enum PaloId{
		OROS(1),COPAS(2),ESPADAS(3),BASTOS(4);
		
		int id;
		
		// Constructor
		private PaloId(int id) {
			this.id = id;
		}
		
		// Getter para saber el id asociado.
		public int getId() {
			return id;
		}

	}

}
*/

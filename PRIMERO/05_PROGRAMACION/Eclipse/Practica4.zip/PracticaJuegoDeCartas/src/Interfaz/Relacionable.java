package Interfaz;

public interface Relacionable {
	
	boolean esMayorQue(Relacionable r);
	
	boolean esMenorQue(Relacionable r);
	
	boolean esIgualQue(Relacionable r);

}

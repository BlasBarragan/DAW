<html>
    <head>
        <title>UNIT 1 - E04</title>
    </head>
    <body>
        <?php
            $x = 2;
            $y = 4;
            echo ("The sum of number " .$x. " and number ".$y." is: " .$x+$y);
            echo ("<br>And the reminder of his division is: " .$x%$y);
        ?>
    </body>
</html>
<!DOCTYPE html>
<html>
	<head>
		<meta charset = "UTF-8">
		<title>Unit 2 - E06</title>
	</head>
	<body>
		<?php
		
        	$x = -34;
            $y = 12;
            
            if ($x < $y) {
            	echo "Numbers are ordered. $x is less than $y";
            }else {
            	echo "Numbers are not ordered. $x is bigger than $y";
            }
        
		?> 
	</body>
</html>
<html>
    <head>
        <title>UNIT 2 - E05</title>
    </head>
    <body>
        <?php
            $x = 25;
            $y = 50;
            if ($x > $y){
                echo ("The number: " .$x. " are greater than number " .$y);
            }if ($x < $y) {
                echo ("The number: " .$x. " are less than number ".$y);
            } else {
                echo ("The number: " .$x. " are equal to number " .$y);
            }
            
        ?>
    </body>
</html>
<html>
    <head>
        <title>UNIT 1 - E02</title>
    </head>
    <body>
        <?php
            $x = 3;
            $y = 20;
            echo ("The sum of two variables are: ".$x+$y);
        ?>
    </body>
</html>

<html>
    <head>
        <title>UNIT 1 - E03</title>
    </head>
    <body>
        <?php
            $r = 4;
            echo ("The circunference of a circle with " .$r."mm radius is: ".(2*pi())*$r);
        ?>
    </body>
</html>
<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

use App\Models\Post;
use App\Models\User;

class PostsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        /* $user = User::factory()->count(3)->create(); */

        User::each(function($user) // for each user, we create 3 fake posts
        {
            $post = Post::factory(3)->create(['user_id' => $user->id]);
        });
        
    }
}

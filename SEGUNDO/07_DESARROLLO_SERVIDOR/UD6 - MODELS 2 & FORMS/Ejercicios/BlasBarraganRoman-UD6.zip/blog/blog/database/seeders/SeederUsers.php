<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

use App\Models\Post;
use App\Models\User;

class SeederUsers extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        /* $user = new User();
        $user->login = 'marta';
        $user->password = 123;
        $user->name = 'Marta';
        $user->save(); */

        // we create 3 fake users
        $user = User::factory()->count(3)->create();
    }
}

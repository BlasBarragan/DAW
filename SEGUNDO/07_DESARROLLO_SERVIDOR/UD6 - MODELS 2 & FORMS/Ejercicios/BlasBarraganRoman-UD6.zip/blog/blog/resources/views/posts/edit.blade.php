
@extends('template')
@section('title', 'Edit Post')
@section('content')

<h1>Edit Post</h1>

{{-- we check for errors and show them --}}
{{-- At head --}}
@if ($errors->any())
    <ul>
        @foreach($errors->all() as $error)
            <li>{{ $error }}</li>
        @endforeach
    </ul>
@endif

<form action="{{ route('posts.update',$post) }}" method="POST">
    @method('PUT') {{-- OJO --}}
    @csrf
    <div class="form-group">
        <label for="title">Title:</label>
        <input type="text" class="form-control" name="title" id="title" value="{{ $post->title }}">
    </div>
    <div class="form-group">
        <label for="content">Content:</label>
        <textarea name="content" placeholder="Content...">
            {{ $post->content }}
        </textarea>
    </div>
    <div class="form-group">
        <label for="user_id">User:</label>
        <select class="form-control" name="user_id" id="user_id">
            @foreach ($users as $user)
                @if ($user->id==$post->user_id)
                    <option value="{{ $user->id }}" selected>
                        {{ $user->name }}
                    </option>
                @else
                    <option value="{{ $user->id }}">
                        {{ $user->name }}
                    </option>
                @endif
            @endforeach
        </select>
    </div>
    <input type="submit" name="send" value="Send"
    class="btn btn-dark btn-block">
</form>

@endsection
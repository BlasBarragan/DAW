@extends('template')

@section('title', 'Home Page')

@section('header', 'Home Page')

@section('content')
<div class="container mt-3">
    <h2 class="text-center">Welcome to the blog</h2>
    <p class="text-center">This is the starting page of your blog application.</p>
</div>
@endsection

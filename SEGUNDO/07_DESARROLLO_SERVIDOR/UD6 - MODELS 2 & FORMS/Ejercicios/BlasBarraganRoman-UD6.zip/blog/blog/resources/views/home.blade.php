@extends('template')

@section('title', 'Home Page')

@section('content')

<h1>Home page</h1>

Welcome to the blog

@endsection

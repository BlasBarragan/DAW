@extends('template')

@section('title', 'Post tab')

@section('content')

<h1>Post title: {{ $post->title }}</h1>
<h2>Content: {{$post->content}}</h2>
Created: {{$post->created_at}}

{{-- <li><a href="{{ route('posts.show', $post)}}">
    {{ $post-> title }} ({{ $post->user->name}}) --}}
    <form action="{{route('posts.destroy', $post)}}" method="POST">
        @method('DELETE')
        @csrf
        <button>Delete</button>
    </form>
    <form action="{{route('posts.edit', $post)}}"> {{-- we call first to edit form and them to update // NO method --}}
        @csrf
        <button>Edit post</button>
    </form>
{{-- </li> --}}

@endsection

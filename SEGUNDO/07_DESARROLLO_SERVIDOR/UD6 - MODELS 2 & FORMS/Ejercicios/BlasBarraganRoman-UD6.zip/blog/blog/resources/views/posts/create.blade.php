
@extends('template')
@section('title', 'New Post')
@section('content')

<h1>New Post</h1>

{{-- we check for errors and show them --}}
{{-- At head --}}
{{-- @if ($errors->any())
    <ul>
        @foreach($errors->all() as $error)
            <li>{{ $error }}</li>
        @endforeach
    </ul>
@endif
 --}}
{{-- In the error that cause error --}}

<form action="{{ route('posts.store') }}" method="POST">
    @csrf

    <div class="form-group">
        <label for="title">Title:</label>
        <input type="text" class="form-control" name="title" id="title" value="{{old('title')}}"> {{-- We add old('title') to have the last value --}}

        {{-- title error --}}
        @if ($errors->has('title'))
            <div class="text-danger">
                {{$errors->first('title')}}
            </div>
        @endif
        
    </div>
    <div class="form-group">
        <label for="content">Content:</label>
        <textarea name="content" placeholder="Content...">
            {{ old('content') }}
        </textarea>

        {{-- content error --}}
        @if ($errors->has('content'))
            <div class="text-danger">
                {{$errors->first('content')}}
            </div>
        @endif
    </div>
    
    <div class="form-group">
        <label for="user">User:</label>
        <select class="form-control" name="user" id="user" value="{{old('user')}}">
            @foreach ($users as $user)
            <option value="{{ $user->id }}">
                {{ $user->name }}
            </option>
            @endforeach
        </select>
    </div>
    <input type="submit" name="send" value="Send" class="btn btn-dark btn-block">
</form>

@endsection
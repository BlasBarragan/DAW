<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\User;

class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //return 'List of Posts';
        $posts = Post::with('user')->orderBy('title', 'asc') ->paginate(5); // with to improve performance
        return view('posts.index', compact('posts'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $users = User::get();
        return view('posts.create', compact('users'));
    }

    // creamos metodo para insertar de forma manual
    public function newPost() {
    
        $post = new Post();
        $post->title = "Title " . rand(0, 9999) ;
        $post->content = "Content " . rand(0, 9999);
        $post->user_id = rand(1, 2);
        $post->save();
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // to validate: 
        request()->validate([
            'title'=>'required|min:5', // required and min 5 characters
            'content'=>'required|min:50', // required and min 50 characters
        ], ['title.required' => 'Title is mandatory, please fill the field with at least of 5 characters', 'content.required'=>'Content is mandatory, please fill the textarea with at least of 50 characters']);

        $post = new Post();
        $post->title = $request->get('title');
        $post->content = $request->get('content');
        $post->user()->associate(User::findOrFail($request->get('user')));
        $post->save();

        return redirect()->route('posts.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(Post $post)
    {

        return view('posts.show', compact('post'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Post $post) // we come here from update button
    {
        $users = User::get(); // get author name
        return view('posts.edit', compact('post', 'users')); // call to posts.edit view with selected post title and user name's
    }

    // creamos metodo para insertar de forma manual
    public function editPost($id) {
        $posttoModify = Post::findOrFail($id);
        $posttoModify->title = "Other title: " . rand(0, 9999);
        $posttoModify->content = "Other content: " . rand(9999, 0);
        $posttoModify->save();
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Post $post) // carefull with parameters (Post $post)
    {
        $post->title = $request->get('title');
        $post->content = $request->get('content');
        $post->user_id=$request->get('user_id');

        $post->save();
        
        return redirect()->route('posts.index'); // return to index
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Post $post)
    {
        $post->delete();
        return redirect()->route('posts.index');
    }
}

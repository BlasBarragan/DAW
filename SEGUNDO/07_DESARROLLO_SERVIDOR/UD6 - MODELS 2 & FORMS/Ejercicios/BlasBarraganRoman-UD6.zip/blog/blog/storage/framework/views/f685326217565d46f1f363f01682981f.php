<?php $__env->startSection('title', 'Home Page'); ?>

<?php $__env->startSection('content'); ?>

<h1>Home page</h1>

Welcome to the blog

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/home.blade.php ENDPATH**/ ?>
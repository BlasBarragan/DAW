<?php $__env->startSection('title', 'New Post'); ?>
<?php $__env->startSection('content'); ?>

<h1>New Post</h1>






<form action="<?php echo e(route('posts.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <div class="form-group">
        <label for="title">Title:</label>
        <input type="text" class="form-control" name="title" id="title" value="<?php echo e(old('title')); ?>"> 

        
        <?php if($errors->has('title')): ?>
            <div class="text-danger">
                <?php echo e($errors->first('title')); ?>

            </div>
        <?php endif; ?>
        
    </div>
    <div class="form-group">
        <label for="content">Content:</label>
        <textarea name="content" placeholder="Content...">
            <?php echo e(old('content')); ?>

        </textarea>

        
        <?php if($errors->has('content')): ?>
            <div class="text-danger">
                <?php echo e($errors->first('content')); ?>

            </div>
        <?php endif; ?>
    </div>
    
    <div class="form-group">
        <label for="user">User:</label>
        <select class="form-control" name="user" id="user" value="<?php echo e(old('user')); ?>">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($user->id); ?>">
                <?php echo e($user->name); ?>

            </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <input type="submit" name="send" value="Send" class="btn btn-dark btn-block">
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/posts/create.blade.php ENDPATH**/ ?>
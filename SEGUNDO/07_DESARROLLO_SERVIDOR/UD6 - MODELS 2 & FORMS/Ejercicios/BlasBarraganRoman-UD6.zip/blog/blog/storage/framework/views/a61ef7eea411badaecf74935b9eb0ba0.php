<?php $__env->startSection('title', 'Edit Post'); ?>
<?php $__env->startSection('content'); ?>

<h1>Edit Post</h1>



<?php if($errors->any()): ?>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>

<form action="<?php echo e(route('posts.update',$post)); ?>" method="POST">
    <?php echo method_field('PUT'); ?> 
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="title">Title:</label>
        <input type="text" class="form-control" name="title" id="title" value="<?php echo e($post->title); ?>">
    </div>
    <div class="form-group">
        <label for="content">Content:</label>
        <textarea name="content" placeholder="Content...">
            <?php echo e($post->content); ?>

        </textarea>
    </div>
    <div class="form-group">
        <label for="user_id">User:</label>
        <select class="form-control" name="user_id" id="user_id">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($user->id==$post->user_id): ?>
                    <option value="<?php echo e($user->id); ?>" selected>
                        <?php echo e($user->name); ?>

                    </option>
                <?php else: ?>
                    <option value="<?php echo e($user->id); ?>">
                        <?php echo e($user->name); ?>

                    </option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <input type="submit" name="send" value="Send"
    class="btn btn-dark btn-block">
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/posts/edit.blade.php ENDPATH**/ ?>
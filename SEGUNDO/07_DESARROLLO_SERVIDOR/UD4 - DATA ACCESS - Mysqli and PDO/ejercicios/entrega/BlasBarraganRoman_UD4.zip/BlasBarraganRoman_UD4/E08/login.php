<?php

$servername = "localhost";
$username = "dwes";
$password = "2DAWdwes";
$dbname = "ies";

?>
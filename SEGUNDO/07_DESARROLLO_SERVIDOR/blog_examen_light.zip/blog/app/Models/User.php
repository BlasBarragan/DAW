<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

/**
 * User Model
 * 
 * This model represents the "users" table in the database.
 * It handles all operations related to application users, such as authentication, 
 * managing user data, and relationships with other models like posts.
 * 
 * Attributes:
 * - id: The unique identifier for the user.
 * - login: The username used for login.
 * - password: The user's hashed password.
 * - remember_token: Used for "remember me" functionality in authentication.
 * - email_verified_at: The timestamp when the user's email was verified.
 * 
 * Relationships:
 * - A user can have many posts.
 */

class User extends Authenticatable
{
    /** 
     * Includes the `HasFactory` trait for creating factories and the `Notifiable` trait for sending notifications.
     * @use HasFactory<\Database\Factories\UserFactory>
     */
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     * These fields can be filled in bulk when creating or updating a user record.
     *
     * @var list<string>
     */
    protected $fillable = [
        'login', // The user's login name.
        'password', // The user's password (stored securely, as specified in the casts).
    ];

    /**
     * Defines a one-to-many relationship with the Post model.
     * A user can have many posts.
     */
    public function posts()
    { 
        return $this->hasMany('App\Models\Post'); // Links the `User` model to multiple `Post` models.
    } 

    /**
     * The attributes that should be hidden for serialization.
     * These attributes will not appear when the user is serialized to JSON or arrays.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password', // Keeps the password hidden when converting the model to an array or JSON.
        'remember_token', // Used for "remember me" functionality in authentication.
    ];

    /**
     * Get the attributes that should be cast.
     * These fields are automatically converted to specific types when accessed.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime', // Automatically casts this attribute to a DateTime object.
            'password' => 'hashed', // Indicates that the password is hashed for security purposes.
        ];
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * Post Model
 * 
 * This model represents the "posts" table in the database.
 * Each post is created by a user (author) and contains details such as title and content.
 * It is used to handle operations like creating, updating, and deleting posts.
 * 
 * Attributes:
 * - id: The unique identifier for the post.
 * - title: The title of the post.
 * - content: The body content of the post.
 * - user_id: The ID of the user (author) who created the post.
 * 
 * Relationships:
 * - A post belongs to a user (author).
 */

class Post extends Model
{
   use HasFactory; // Includes the factory trait for the Post model, enabling the creation of test data using factories.
   
   // Specifies the attributes that can be mass-assigned.
   protected $fillable = ['id', 'title', 'content', 'user_id'];

   /**
    * Defines the relationship between the Post model and the User model.
    * A post belongs to a single user.
    */
   public function user()
   { 
       return $this->belongsTo('App\Models\User'); // Indicates that each post is associated with one user.
   } 
}

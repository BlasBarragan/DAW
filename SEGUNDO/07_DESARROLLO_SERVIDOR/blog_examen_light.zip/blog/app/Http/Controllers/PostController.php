<?php

namespace App\Http\Controllers;

/**  
 * This controller handle all actions related to posts
 * such as displaying posts, creating new ones, editing,
 * updating, and deleting them.
 */

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\User;

class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     * Retrieves a paginated list of posts, ordered alphabetically by title.
     */
    public function index()
    {
        $posts = Post::orderBy('title', 'asc') // Order posts by title in ascending order.
                     ->paginate(5); // Paginate the results, displaying 5 posts per page.
        return view('posts.index', compact('posts')); // Return the 'posts.index' view with the posts data.
    }

    /**
     * Show the form for creating a new resource.
     * Displays the form to create a new post.
     */
    public function create()
    {
        $users = User::all(); // Retrieve all users to assign them to a post.
        return view('posts.create', compact('users')); // Return the 'posts.create' view with the list of users.
    }

    /**
     * Store a newly created resource in storage.
     * Validates and saves a new post in the database.
     */
    public function store(Request $request)
    {
        // Validate the form inputs.
        $request->validate([
            'title' => 'required|min:5', // The title is required and must have at least 5 characters.
            'content' => 'required|min:50', // The content is required and must have at least 50 characters.
            'user_id' => 'required|exists:users,id', // The user_id is required and must exist in the 'users' table.
        ], [
            'title.required' => 'The title is mandatory.', // Custom error message for missing title.
            'title.min' => 'The title must be at least 5 characters long.', // Custom error for short title.
            'content.required' => 'The content is mandatory.', // Custom error for missing content.
            'content.min' => 'The content must be at least 50 characters long.', // Custom error for short content.
        ]);
    
        Post::create($request->all()); // Create a new post using the validated data.
    
        return redirect()->route('posts.index'); // Redirect to the posts index page.
    }

    /**
     * Display the specified resource.
     * Shows a single post by its ID.
     */
    public function show($id)
    {
        $post = Post::findOrFail($id); // Find the post by ID or throw a 404 error if not found.
        return view('posts.show', compact('post')); // Return the 'posts.show' view with the post data.
    }

    /**
     * Show the form for editing the specified resource.
     * Displays the form to edit an existing post.
     */
    public function edit(Post $post)
    {
        $users = User::all(); // Retrieve all users to populate the dropdown
        return view('posts.edit', compact('post', 'users')); // Pass the post and users to the view
    }

    /**
     * Update the specified resource in storage.
     * Validates and updates an existing post in the database.
     */
    public function update(Request $request, Post $post)
    {
        // Validate the form inputs.
        $request->validate([
            'title' => 'required|min:5', // The title is required and must have at least 5 characters.
            'content' => 'required|min:50', // The content is required and must have at least 50 characters.
            'user_id' => 'required|exists:users,id', // user_id mandatory
        ]);

        $post->update($request->all()); // Update the post with the validated data.

        return redirect()->route('posts.index'); // Redirect to the posts index page.
    }

    /**
     * Remove the specified resource from storage.
     * Deletes a post by its ID.
     */
    public function destroy(string $id)
    {
        $post = Post::findOrFail($id); // Find the post by ID or throw a 404 error if not found.
        $post->delete(); // Delete the post from the database.
    
        return redirect()->route('posts.index'); // Redirect to the posts index page.
    }

    /**
     * Creates a new post with dummy data.
     * Used for testing or creating example posts.
     */
    public function newPost()
    {
        $adminID = 1; // Default admin user ID.
        $post = new Post(); // Create a new Post instance.
        $post->title = 'Title ' . rand(1, 1000); // Generate a random title.
        $post->content = 'Content ' . rand(1, 1000); // Generate random content.
        $post->user_id = $adminID; // Assign the post to the admin user.
        $post->save(); // Save the post to the database.
    }

    /**
     * Updates an existing post with dummy data.
     * Finds a post by ID and updates its title and content.
     */
    public function editPost($id)
    {
        $post = Post::find($id); // Find the post by ID.

        if ($post) {
            $post->title = 'Title ' . rand(1, 1000); // Generate a new random title.
            $post->content = 'Content ' . rand(1, 1000); // Generate new random content.
            $post->save(); // Save the updated post.

            return "Post with ID $id updated!"; // Return a success message.
        } else {
            return "Post not found!"; // Return an error message if the post does not exist.
        }
    }
}

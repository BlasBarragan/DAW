<!-- List of posts view -->

@extends('template')

@section('title', 'List of Posts')

@section('header', 'List of Posts')

@section('content')
<p>This is the list of posts.</p>

<ul>
    @isset($posts) <!-- Check if the 'posts' variable is set and not null -->
        @forelse ($posts as $post) <!-- Loop through each post if available -->
            <li>
                <!-- Display the title of the post -->
                <strong>{{ $post->title }}</strong>  

                <!-- Check if the post has an associated user -->
                @if ($post->user)
                    <!-- Display the login name of the user associated with the post -->
                    ({{ $post->user->login }})
                @else
                    <!-- Display 'No user assigned' if the post doesn't have a user -->
                    (No user assigned)
                @endif
                
                <!-- Link to view the post details -->
                <a href="{{ route('posts.show', $post->id) }}" class="btn btn-primary btn-sm">View</a>
                <!-- Link to edit the post -->
                <!-- <a href="{{ route('posts.edit', $post->id) }}" class="btn btn-warning btn-sm">Edit</a> -->

                <!-- Form to delete the post -->
                <!-- <form action="{{ route('posts.destroy', $post->id) }}" method="POST" style="display:inline;"> -->
                    @csrf <!-- CSRF token for security -->
                    @method('DELETE') <!-- Simulates a DELETE request -->
                    <!-- Submit button for deleting the post with a confirmation prompt -->
                    <!-- <button type="submit" class="btn btn-danger btn-sm" -->
                        <!-- onclick="return confirm('Are you sure you want to delete this post?')"> -->
                        <!-- Delete -->
                    <!-- </button> -->
                <!-- </form> -->
            </li>
        @empty <!-- If no posts exist -->
            <li>No posts found</li>
        @endforelse
    @else <!-- If the 'posts' variable is not set -->
        <li>No posts to display</li>
    @endisset
</ul>

<!-- Pagination links for the posts -->
{{ $posts->links() }}
@endsection 
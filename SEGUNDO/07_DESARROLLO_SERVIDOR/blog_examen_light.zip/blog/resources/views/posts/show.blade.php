<!-- Individual post view -->

@extends('template') 

@section('title', 'Post Details')

@section('content')

<h1>{{ $post->title }}</h1> <!-- Display the title of the post -->

<p>{{ $post->content }}</p> <!-- Display the content of the post -->

<!-- Check if the post has an associated user -->
@if ($post->user)
    <p><strong>Author:</strong> {{ $post->user->login }}</p> <!-- Display the user's login if a user is assigned -->
@else
    <p><strong>Author:</strong> No user assigned</p> <!-- Display 'No user assigned' if no user is assigned -->
@endif

<!-- Display the creation and last updated timestamps in a readable format -->
<p><strong>Created at:</strong> {{ $post->created_at->format('Y-m-d H:i') }}</p> <!-- Format the creation date -->
<p><strong>Last updated:</strong> {{ $post->updated_at->format('Y-m-d H:i') }}</p> <!-- Format the last update date -->

<!-- Button to update the post -->
<a href="{{ route('posts.edit', $post->id) }}" class="btn btn-warning" style="margin-right: 10px;">Update Post</a>

<!-- Form to delete the post -->
<form action="{{ route('posts.destroy', $post->id) }}" method="POST" style="display:inline;">
    @csrf <!-- CSRF token for security -->
    @method('DELETE') <!-- Simulates a DELETE request -->
    <!-- Submit button to delete the post with a confirmation prompt -->
    <button type="submit" class="btn btn-danger"
        onclick="return confirm('Are you sure you want to delete this post?')">
        Delete Post
    </button>
</form>

@endsection 
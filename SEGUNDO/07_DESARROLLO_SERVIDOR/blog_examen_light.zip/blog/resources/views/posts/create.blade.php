<!-- Create new post view -->

@extends('template')
@section('title', 'New Post')
@section('content')

<h1>New post</h1>

<!-- Check if there are any validation errors and display them -->
@if ($errors->any())
    <ul>
        @foreach($errors->all() as $error) <!-- Loop through each error message -->
            <li>{{ $error }}</li> <!-- Display each error -->
        @endforeach
    </ul>
@endif

<!-- Form to create a new post -->
<form action="{{ route('posts.store') }}" method="POST">
    @csrf <!-- Include a CSRF token for security -->

    <!-- Title input field -->
    <label>Title</label>
    <input type="text" name="title" value="{{ old('title') }}"> <!-- Preserves the input value if validation fails -->
    
    <!-- Display error message for title if it exists -->
    @if ($errors->has('title'))
        <div class="text-danger">{{ $errors->first('title') }}</div>
    @endif

    <!-- Content input field -->
    <label>Content</label>
    <textarea name="content">{{ old('content') }}</textarea> <!-- Preserves the input value if validation fails -->
    
    <!-- Display error message for content if it exists -->
    @if ($errors->has('content'))
        <div class="text-danger">{{ $errors->first('content') }}</div>
    @endif

    <!-- Dropdown to select user -->
    <label>User</label>
    <select name="user_id">
        <option value="">Select an author</option> <!-- Placeholder option -->
        @foreach($users as $user) <!-- Loop through users and create an option for each -->
            <option value="{{ $user->id }}">{{ $user->login }}</option> <!-- Display the user's login as option text -->
        @endforeach
    </select>

    <!-- Display error message for user_id if it exists -->
    @if ($errors->has('user_id'))
        <div class="text-danger">{{ $errors->first('user_id') }}</div>
    @endif

    <!-- Submit button to create the post -->
    <button type="submit" class="btn btn-success mt-3">Create</button>
</form>

@endsection 
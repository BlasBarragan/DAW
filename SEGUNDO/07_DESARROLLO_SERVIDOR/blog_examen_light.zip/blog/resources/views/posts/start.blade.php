<!-- Home page -->

@extends('template')

@section('title', 'Home Page')

@section('header', 'Home Page')

@section('content')
<div class="container mt-3"> <!-- Creates a container for the page content with a top margin of 3 -->
    <h2 class="text-center">Welcome to the blog</h2> <!-- A centered heading for the welcome message -->
    <p class="text-center">This is the starting page of your blog application.</p> <!-- A centered paragraph introducing the blog -->
</div>

@endsection <!-- End content section -->

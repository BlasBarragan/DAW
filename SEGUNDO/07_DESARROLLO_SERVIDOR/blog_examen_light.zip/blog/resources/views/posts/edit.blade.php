<!-- Edit post view -->

@extends('template')
@section('title', 'Edit Post')
@section('content')

<h1>Edit post</h1>

<!-- Check if there are any validation errors and display them -->
@if ($errors->any())
    <ul>
        @foreach($errors->all() as $error) <!-- Loop through each error message -->
            <li>{{ $error }}</li> <!-- Display each error -->
        @endforeach
    </ul>
@endif

<!-- Form to edit an existing post -->
<form action="{{ route('posts.update', $post) }}" method="POST">
    @csrf <!-- Include a CSRF token for security -->
    @method('PUT') <!-- Specifies that this is a PUT request (used for updating resources) -->

    <!-- Title input field -->
    <label>Title</label>
    <input type="text" name="title" value="{{ old('title', $post->title) }}"> <!-- Preserve the input value if validation fails, otherwise show current title -->
    
    <!-- Display error message for title if it exists -->
    @if ($errors->has('title'))
        <div class="text-danger">{{ $errors->first('title') }}</div>
    @endif

    <!-- Content input field -->
    <label>Content</label>
    <textarea name="content">{{ old('content', $post->content) }}</textarea> <!-- Preserve the input value if validation fails, otherwise show current content -->
    
    <!-- Display error message for content if it exists -->
    @if ($errors->has('content'))
        <div class="text-danger">{{ $errors->first('content') }}</div>
    @endif

    <!-- User select field -->
    <label>Author</label>
    <select name="user_id">
        @foreach ($users as $user)
            <option value="{{ $user->id }}" {{ old( "user_id", $post->user_id) == $user->id ? 'selected' : '' }}>
                {{ $user->login }}
            </option>
        @endforeach
    </select>

    <!-- Submit button to update the post -->
    <button type="submit" class="btn btn-success mt-3">Update</button>
</form>

@endsection 
<!-- Template base layout -->

<html>
<head>
@vite(['resources/css/app.css', 'resources/js/app.js'])
    <!-- Sets the title of the page using the 'title' section defined in individual views -->
    <title>
        @yield('title') <!-- This will be replaced with the title defined in each individual view -->
    </title>
</head>
<body>
    <!-- Include the 'partials.nav' view for the navigation bar -->
    @include('partials.nav')

    <!-- Yield the content section of the page (this is where the content from other views will be inserted) -->
    @yield('content') 
<nav class="navbar navbar-dark bg-dark">
    <!-- Navbar container to center the navbar content -->
    <div class="container">
        <!-- Brand link that navigates to the home page, using the 'home' route -->
        <a class="navbar-brand" href="{{ route('home') }}">Blog</a>
        
        <!-- Navbar links aligned to the right using 'ms-auto' (Bootstrap class for margin start auto) and flex layout -->
        <ul class="navbar-nav ms-auto d-flex flex-row">
            <!-- Home page link -->
            <li class="nav-item">
                <a class="nav-link" href="{{ route('home') }}">Home page</a>
            </li>

            <!-- List of posts page link -->
            <li class="nav-item">
                <a class="nav-link" href="{{ route('posts.index') }}">List of posts</a>
            </li>

            <!-- Create new post page link -->
            <li class="nav-item">
                <a class="nav-link" href="{{ route('posts.create') }}">Create new post</a>
            </li>
        </ul>
    </div>
</nav>

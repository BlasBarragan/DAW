<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Post;
use App\Models\User;

/**
 * Factory for creating fake data for the Post model.
 * 
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Post>
 */
class PostFactory extends Factory
{
    /**
     * Define the model's default state.
     * This method specifies the default data that will be used to create a fake Post.
     *
     * @return array<string, mixed> The array of attributes to populate the Post model.
     */
    public function definition(): array
    {
        return [
            'title' => fake()->sentence(), // Generates a fake sentence for the title.
            'content' => fake()->text(), // Generates fake text for the content.
            'user_id' => User::inRandomOrder()->first()->id, // Randomly selects a user ID from the users table.
        ];
    }
}

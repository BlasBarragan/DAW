<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * Factory for creating fake data for the User model.
 * 
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\User>
 */
class UserFactory extends Factory
{
    /**
     * Define the model's default state.
     * Specifies the default data to be generated for the User model.
     *
     * @return array<string, mixed> The array of attributes to populate the User model.
     */
    public function definition(): array
    {
        return [
            'login' => fake()->unique()->word(), // Generates a unique word for the 'login' field.
            'password' => fake()->word(), // Generates a random word for the 'password' field.
        ];
    }
}

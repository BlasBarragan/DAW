<?php

/**
 * PostsSeeder
 * 
 * This seeder populates the "posts" table with data by creating multiple posts 
 * for each user in the database. It uses the `Post` factory to generate realistic 
 * or random content for testing or initializing the application with sample data.
 * 
 * Purpose:
 * - To associate posts with existing users.
 * - To simulate a real-world scenario where each user creates multiple posts.
 * 
 * Functionality:
 * - Iterates over all users in the `users` table.
 * - For each user, it creates 3 posts using the `Post` factory.
 * - Each generated post is linked to the user through the `user_id` field.
 * 
 * Usage:
 * - This seeder is typically called by the `DatabaseSeeder` class.
 * - Run the seeder using: `php artisan db:seed --class=PostsSeeder`.
 */

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\User; // Import the User model to associate posts with users.
use App\Models\Post; // Import the Post model to create posts.

class PostsSeeder extends Seeder
{
    /**
     * Run the database seeds.
 * This method creates posts for each user in the database.
     */
    public function run(): void
    {
        // Retrieve all users and iterate over each user.
        User::all()->each(function ($user) {  
            // For each user, generate 3 posts using the Post factory.
            Post::factory()
                ->count(3) // Specify the number of posts to create.
                ->create(['user_id' => $user->id]); // Associate each post with the current user's ID.
        });  
    }
}
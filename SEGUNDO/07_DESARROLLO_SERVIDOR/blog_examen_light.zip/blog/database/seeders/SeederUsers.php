<?php
/**
 * SeederUsers
 * 
 * This seeder populates the "users" table with fake user data using the `User` factory. 
 * It is used to create sample users for testing or initializing the database with 
 * predefined data for development purposes.
 * 
 * Purpose:
 * - To populate the `users` table with a specific number of user records.
 * - To simulate a real-world scenario where users exist in the application.
 * 
 * Functionality:
 * - Uses the `User` factory to generate 3 user records with random or realistic data.
 * - Saves the generated users to the database.
 * 
 * Usage:
 * - This seeder is typically called by the `DatabaseSeeder` class.
 * - Run the seeder using: `php artisan db:seed --class=SeederUsers`.
 */


namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\User; // Import the User model to create user records.

class SeederUsers extends Seeder
{
    /**
     * Run the database seeds.
    * This method creates a specified number of users in the database using the User factory.
     */
    public function run(): void
    {
        // Generate and insert 3 fake user records into the 'users' table using the User factory.
        User::factory()
            ->count(3) // Specifies the number of user records to create.
            ->create(); // Saves the generated users to the database.
    }
}
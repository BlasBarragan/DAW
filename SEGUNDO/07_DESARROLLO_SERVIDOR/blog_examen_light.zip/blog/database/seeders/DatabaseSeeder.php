<?php

/**
 * DatabaseSeeder
 * 
 * This file is the entry point for seeding the application's database.
 * It runs all the defined seeders in the project to populate the database with initial or test data.
 * 
 * Purpose:
 * - To initialize the database with default values or fake data for testing and development.
 * - To centralize and organize the seeding process by calling multiple seeders.
 * - To ensure consistent data across environments (e.g., local development, testing).
 * 
 * Usage:
 * - Run the seeder using the command: `php artisan db:seed`.
 * - To reset the database and seed it from scratch, use: `php artisan migrate:fresh --seed`.
 * 
 * Key Sections:
 * - `run` method: Executes specific seeders defined in the `call` method.
 * - Called seeders:
 *   - `SeederUsers`: Seeds the `users` table.
 *   - `PostsSeeder`: Seeds the `posts` table.
 */


namespace Database\Seeders;

use App\Models\User; // Import the User model for potential use in this seeder.
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     * This method runs all the defined seeders to populate the database with test or initial data.
     */
    public function run(): void
    {
        // Call multiple seeders to seed the database with users, posts, and other data.
        $this->call([
            SeederUsers::class, // Seeds the users table with fake or predefined data.
            PostsSeeder::class, // Seeds the posts table with fake or predefined data.
        ]);
    }
}
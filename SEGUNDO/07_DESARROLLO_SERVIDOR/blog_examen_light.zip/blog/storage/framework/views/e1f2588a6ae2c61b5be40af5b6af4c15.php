<!-- List of posts view -->



<?php $__env->startSection('title', 'List of Posts'); ?>

<?php $__env->startSection('header', 'List of Posts'); ?>

<?php $__env->startSection('content'); ?>
<p>This is the list of posts.</p>

<ul>
    <?php if(isset($posts)): ?> <!-- Check if the 'posts' variable is set and not null -->
        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> <!-- Loop through each post if available -->
            <li>
                <!-- Display the title of the post -->
                <strong><?php echo e($post->title); ?></strong>  

                <!-- Check if the post has an associated user -->
                <?php if($post->user): ?>
                    <!-- Display the login name of the user associated with the post -->
                    (<?php echo e($post->user->login); ?>)
                <?php else: ?>
                    <!-- Display 'No user assigned' if the post doesn't have a user -->
                    (No user assigned)
                <?php endif; ?>
                
                <!-- Link to view the post details -->
                <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="btn btn-primary btn-sm">View</a>
                <!-- Link to edit the post -->
                <!-- <a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="btn btn-warning btn-sm">Edit</a> -->

                <!-- Form to delete the post -->
                <!-- <form action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="POST" style="display:inline;"> -->
                    <?php echo csrf_field(); ?> <!-- CSRF token for security -->
                    <?php echo method_field('DELETE'); ?> <!-- Simulates a DELETE request -->
                    <!-- Submit button for deleting the post with a confirmation prompt -->
                    <!-- <button type="submit" class="btn btn-danger btn-sm" -->
                        <!-- onclick="return confirm('Are you sure you want to delete this post?')"> -->
                        <!-- Delete -->
                    <!-- </button> -->
                <!-- </form> -->
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <!-- If no posts exist -->
            <li>No posts found</li>
        <?php endif; ?>
    <?php else: ?> <!-- If the 'posts' variable is not set -->
        <li>No posts to display</li>
    <?php endif; ?>
</ul>

<!-- Pagination links for the posts -->
<?php echo e($posts->links()); ?>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/posts/index.blade.php ENDPATH**/ ?>
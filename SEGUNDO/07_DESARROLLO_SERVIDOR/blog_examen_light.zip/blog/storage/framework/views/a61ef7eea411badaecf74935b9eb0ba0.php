<!-- Edit post view -->


<?php $__env->startSection('title', 'Edit Post'); ?>
<?php $__env->startSection('content'); ?>

<h1>Edit post</h1>

<!-- Check if there are any validation errors and display them -->
<?php if($errors->any()): ?>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- Loop through each error message -->
            <li><?php echo e($error); ?></li> <!-- Display each error -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>

<!-- Form to edit an existing post -->
<form action="<?php echo e(route('posts.update', $post)); ?>" method="POST">
    <?php echo csrf_field(); ?> <!-- Include a CSRF token for security -->
    <?php echo method_field('PUT'); ?> <!-- Specifies that this is a PUT request (used for updating resources) -->

    <!-- Title input field -->
    <label>Title</label>
    <input type="text" name="title" value="<?php echo e(old('title', $post->title)); ?>"> <!-- Preserve the input value if validation fails, otherwise show current title -->
    
    <!-- Display error message for title if it exists -->
    <?php if($errors->has('title')): ?>
        <div class="text-danger"><?php echo e($errors->first('title')); ?></div>
    <?php endif; ?>

    <!-- Content input field -->
    <label>Content</label>
    <textarea name="content"><?php echo e(old('content', $post->content)); ?></textarea> <!-- Preserve the input value if validation fails, otherwise show current content -->
    
    <!-- Display error message for content if it exists -->
    <?php if($errors->has('content')): ?>
        <div class="text-danger"><?php echo e($errors->first('content')); ?></div>
    <?php endif; ?>

    <!-- User select field -->
    <label>Author</label>
    <select name="user_id">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($user->id); ?>" <?php echo e(old( "user_id", $post->user_id) == $user->id ? 'selected' : ''); ?>>
                <?php echo e($user->login); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <!-- Submit button to update the post -->
    <button type="submit" class="btn btn-success mt-3">Update</button>
</form>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/posts/edit.blade.php ENDPATH**/ ?>
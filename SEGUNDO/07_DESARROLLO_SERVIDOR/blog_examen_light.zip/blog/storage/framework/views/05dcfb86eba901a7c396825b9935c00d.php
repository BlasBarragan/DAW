<!-- Create new post view -->


<?php $__env->startSection('title', 'New Post'); ?>
<?php $__env->startSection('content'); ?>

<h1>New post</h1>

<!-- Check if there are any validation errors and display them -->
<?php if($errors->any()): ?>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- Loop through each error message -->
            <li><?php echo e($error); ?></li> <!-- Display each error -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>

<!-- Form to create a new post -->
<form action="<?php echo e(route('posts.store')); ?>" method="POST">
    <?php echo csrf_field(); ?> <!-- Include a CSRF token for security -->

    <!-- Title input field -->
    <label>Title</label>
    <input type="text" name="title" value="<?php echo e(old('title')); ?>"> <!-- Preserves the input value if validation fails -->
    
    <!-- Display error message for title if it exists -->
    <?php if($errors->has('title')): ?>
        <div class="text-danger"><?php echo e($errors->first('title')); ?></div>
    <?php endif; ?>

    <!-- Content input field -->
    <label>Content</label>
    <textarea name="content"><?php echo e(old('content')); ?></textarea> <!-- Preserves the input value if validation fails -->
    
    <!-- Display error message for content if it exists -->
    <?php if($errors->has('content')): ?>
        <div class="text-danger"><?php echo e($errors->first('content')); ?></div>
    <?php endif; ?>

    <!-- Dropdown to select user -->
    <label>User</label>
    <select name="user_id">
        <option value="">Select an author</option> <!-- Placeholder option -->
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- Loop through users and create an option for each -->
            <option value="<?php echo e($user->id); ?>"><?php echo e($user->login); ?></option> <!-- Display the user's login as option text -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <!-- Display error message for user_id if it exists -->
    <?php if($errors->has('user_id')): ?>
        <div class="text-danger"><?php echo e($errors->first('user_id')); ?></div>
    <?php endif; ?>

    <!-- Submit button to create the post -->
    <button type="submit" class="btn btn-success mt-3">Create</button>
</form>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/posts/create.blade.php ENDPATH**/ ?>
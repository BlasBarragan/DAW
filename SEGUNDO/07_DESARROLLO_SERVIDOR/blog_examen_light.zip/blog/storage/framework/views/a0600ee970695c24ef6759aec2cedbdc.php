<!-- Individual post view -->

 

<?php $__env->startSection('title', 'Post Details'); ?>

<?php $__env->startSection('content'); ?>

<h1><?php echo e($post->title); ?></h1> <!-- Display the title of the post -->

<p><?php echo e($post->content); ?></p> <!-- Display the content of the post -->

<!-- Check if the post has an associated user -->
<?php if($post->user): ?>
    <p><strong>Author:</strong> <?php echo e($post->user->login); ?></p> <!-- Display the user's login if a user is assigned -->
<?php else: ?>
    <p><strong>Author:</strong> No user assigned</p> <!-- Display 'No user assigned' if no user is assigned -->
<?php endif; ?>

<!-- Display the creation and last updated timestamps in a readable format -->
<p><strong>Created at:</strong> <?php echo e($post->created_at->format('Y-m-d H:i')); ?></p> <!-- Format the creation date -->
<p><strong>Last updated:</strong> <?php echo e($post->updated_at->format('Y-m-d H:i')); ?></p> <!-- Format the last update date -->

<!-- Button to update the post -->
<a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="btn btn-warning" style="margin-right: 10px;">Update Post</a>

<!-- Form to delete the post -->
<form action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="POST" style="display:inline;">
    <?php echo csrf_field(); ?> <!-- CSRF token for security -->
    <?php echo method_field('DELETE'); ?> <!-- Simulates a DELETE request -->
    <!-- Submit button to delete the post with a confirmation prompt -->
    <button type="submit" class="btn btn-danger"
        onclick="return confirm('Are you sure you want to delete this post?')">
        Delete Post
    </button>
</form>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/posts/show.blade.php ENDPATH**/ ?>
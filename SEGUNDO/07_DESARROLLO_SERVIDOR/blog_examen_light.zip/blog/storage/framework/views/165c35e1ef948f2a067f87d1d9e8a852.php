<!-- Home page -->



<?php $__env->startSection('title', 'Home Page'); ?>

<?php $__env->startSection('header', 'Home Page'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-3"> <!-- Creates a container for the page content with a top margin of 3 -->
    <h2 class="text-center">Welcome to the blog</h2> <!-- A centered heading for the welcome message -->
    <p class="text-center">This is the starting page of your blog application.</p> <!-- A centered paragraph introducing the blog -->
</div>

<?php $__env->stopSection(); ?> <!-- End content section -->

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/posts/start.blade.php ENDPATH**/ ?>
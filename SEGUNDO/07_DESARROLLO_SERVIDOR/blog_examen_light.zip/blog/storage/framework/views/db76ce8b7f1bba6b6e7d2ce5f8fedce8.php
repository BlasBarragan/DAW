<!-- Template base layout -->

<html>
<head>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <!-- Sets the title of the page using the 'title' section defined in individual views -->
    <title>
        <?php echo $__env->yieldContent('title'); ?> <!-- This will be replaced with the title defined in each individual view -->
    </title>
</head>
<body>
    <!-- Include the 'partials.nav' view for the navigation bar -->
    <?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Yield the content section of the page (this is where the content from other views will be inserted) -->
    <?php echo $__env->yieldContent('content'); ?> <?php /**PATH /app/resources/views/template.blade.php ENDPATH**/ ?>
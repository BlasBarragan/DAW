<?php

use Illuminate\Support\Facades\Route;

/**
 * web.php
 * 
 * This file defines the web routes for the application. 
 * Routes map specific URLs to their corresponding logic (controllers, views, or closures),
 * enabling users to access specific features or pages of the website.
 * 
 * Purpose:
 * - To define routes for the application that respond to HTTP requests.
 * - To handle both static routes (e.g., basic closures) and dynamic routes (e.g., parameterized URLs).
 * - To define resourceful routes for controllers, allowing CRUD operations in a standardized way.
 * 
 * Key Sections:
 * - Basic routes: Examples of static and dynamic routes with optional parameters and validation.
 * - Controller routes: Resourceful routes linked to the `PostController` for managing posts.
 * - Named routes: Assigning names to routes for easier referencing in the application.
 */


//Route::get('/', function () {
//    return view('welcome');
//});

//Exercise 1
Route::get('fecha', function() {
    return date("d/m/y h:i:s");
});

Route::get('greeting/{name?}/{id?}', function($name = "Guest", $id = 0) {
    return "Hello $name, your code is the $id";
})->where('name', "[A-Za-z]+") 
  ->where('id', "[0-9]+") 
  ->name('greeting'); 


//Excercise 2
//  Route::get('posts', function() {
//    return "List of posts";
//})->name('posts_list'); 


//Route::get('posts/{id}', function($id) {
//    return "Post number $id";
//})->where('id', "[0-9]+") 
//  ->name('post_number'); 


//Route::get('/', function() {
//    return "Welcome to the homepage";
//})->name('home'); 


//Exercise 1.1
// Route::get('posts', function() {
//     return view('posts.listing');
// })->name('posts_list');

// Route::get('posts/{id}', function($id) {
//     return view('posts.tab', ['id' => $id]);
// })->where('id', "[0-9]+")
//   ->name('post_number');

Route::get('/', function() {
    return view('posts.start');    // Returns the 'posts.start' view (homepage of the blog)
})->name('home');// Names the route for the homepage

//Controller activity
use App\Http\Controllers\PostController;

Route::resource('posts', PostController::class)->only(['index', 'show', 'create', 'edit', 'destroy']); // Route to handle resourceful routes for 'posts', allowing actions like index, show, create, edit, and destroy
Route::get('newPost', [PostController::class, 'newPost']);// Route for creating a new post
Route::get('editPost/{id}', [PostController::class, 'editPost']); // Route for editing a post
Route::resource('posts', PostController::class); // Full resource route for 'posts' with all standard actions (index, show, create, edit, store, update, destroy)
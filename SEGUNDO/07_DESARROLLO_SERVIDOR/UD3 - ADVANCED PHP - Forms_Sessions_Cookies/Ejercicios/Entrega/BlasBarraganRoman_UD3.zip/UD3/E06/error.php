<html>

<head>
  <title>error.php UNIT3 - E06</title>
</head>

<body>

  <h1 style="color: red;"> Locked account!!</h1>

</body>

</html>
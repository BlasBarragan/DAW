<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;

class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //return 'List of Posts';
        $posts = Post::orderBy('title', 'asc') ->paginate(5);
        return view('posts.index', compact('posts'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return 'New post';
    }

    // creamos metodo para insertar de forma manual
    public function newPost() {
    
        $post = new Post();
        $post->title = "Title " . rand(0, 9999) ;
        $post->content = "Content " . rand(0, 9999);
        $post->save();
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Post $post)
    {

        return view('posts.show', compact('post'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        return 'Post edit';
    }

    // creamos metodo para insertar de forma manual
    public function editPost($id) {
        $posttoModify = Post::findOrFail($id);
        $posttoModify->title = "Other title: " . rand(0, 9999);
        $posttoModify->content = "Other content: " . rand(9999, 0);
        $posttoModify->save();
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Post $post)
    {
        $post->delete();
        return redirect()->route('posts.index');
    }
}

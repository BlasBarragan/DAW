<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PostController;

Route::get('/', function () {
    return view('home');
}) -> name('home');

/*
Route::get('posts', function() {
    //return 'List of Posts';
    return view('posts/listing');
}) -> name('posts_list');

Route::get('posts/{id}', function($id) {
    //return "Post number $id" ;
    return view('posts/tab') -> with('id', $id);
}) ->where('id', "[0-9]+")
-> name('post_number');
*/

Route::resource('posts', PostController::class);
//->only(['index', 'show', 'create', 'edit']);

Route::get('newPost', [PostController::class, 'newPost']);

Route::get('editPost/{id}', [PostController::class, 'editPost']);
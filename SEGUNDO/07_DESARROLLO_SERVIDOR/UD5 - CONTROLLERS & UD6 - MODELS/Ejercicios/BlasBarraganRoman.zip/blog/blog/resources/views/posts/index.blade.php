@extends('template')

@section('title', 'List of post')

@section('content')

<h1>List of post</h1>
<ul>
    @isset($posts)
    @forelse ($posts as $post)
    <li>{{ $post-> title }}
        <form action="{{route('posts.show', $post)}}" method="GET">
            @csrf
            <button>View</button>
        </form>
        <form action="{{route('posts.destroy', $post)}}" method="POST">
            @method('DELETE')
            @csrf
            <button>Delete</button>
        </form>
    </li>
    @empty
    <li>No posts found</li>
    @endforelse
    @else
    <li>No posts to display</li>
    @endisset
</ul>
{{$posts->links()}};
@endsection

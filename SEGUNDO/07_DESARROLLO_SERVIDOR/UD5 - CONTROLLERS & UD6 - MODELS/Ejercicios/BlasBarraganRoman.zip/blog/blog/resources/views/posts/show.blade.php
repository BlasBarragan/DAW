@extends('template')

@section('title', 'Post tab')

@section('content')

<h1>Post title: {{ $post->title }}</h1>
<h2>Content: {{$post->content}}</h2>
Created: {{$post->created_at}}

@endsection

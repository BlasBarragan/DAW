<?php $__env->startSection('title', 'Post tab'); ?>

<?php $__env->startSection('content'); ?>

<h1>Post title: <?php echo e($post->title); ?></h1>
<h2>Content: <?php echo e($post->content); ?></h2>
Created: <?php echo e($post->created_at); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/posts/show.blade.php ENDPATH**/ ?>
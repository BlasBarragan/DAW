<?php $__env->startSection('title', 'Post tab'); ?>

<?php $__env->startSection('content'); ?>

    <?php if(isset($id)): ?>
        <h1>Post tab <?php echo e($id); ?></h1>
    <?php else: ?>
        <h1>No id in URL</h1>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/posts/tab.blade.php ENDPATH**/ ?>
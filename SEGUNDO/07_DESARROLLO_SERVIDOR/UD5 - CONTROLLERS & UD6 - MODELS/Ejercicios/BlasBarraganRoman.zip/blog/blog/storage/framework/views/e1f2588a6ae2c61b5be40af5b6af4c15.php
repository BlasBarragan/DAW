<?php $__env->startSection('title', 'List of post'); ?>

<?php $__env->startSection('content'); ?>

<h1>List of post</h1>
<ul>
    <?php if(isset($posts)): ?>
    <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <li><?php echo e($post-> title); ?>

        <form action="<?php echo e(route('posts.show', $post)); ?>" method="GET">
            <?php echo csrf_field(); ?>
            <button>View</button>
        </form>
        <form action="<?php echo e(route('posts.destroy', $post)); ?>" method="POST">
            <?php echo method_field('DELETE'); ?>
            <?php echo csrf_field(); ?>
            <button>Delete</button>
        </form>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <li>No posts found</li>
    <?php endif; ?>
    <?php else: ?>
    <li>No posts to display</li>
    <?php endif; ?>
</ul>
<?php echo e($posts->links()); ?>;
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/posts/index.blade.php ENDPATH**/ ?>
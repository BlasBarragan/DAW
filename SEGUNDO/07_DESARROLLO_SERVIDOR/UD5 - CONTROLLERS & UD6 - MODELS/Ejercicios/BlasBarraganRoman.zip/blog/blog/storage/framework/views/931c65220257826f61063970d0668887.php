<?php $__env->startSection('title', 'List of post'); ?>

<?php $__env->startSection('content'); ?>

<h1>List of post</h1>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/posts/listing.blade.php ENDPATH**/ ?>
<html>

<head>
  <title>UNIT 2 - E06</title>
</head>

<body>
  <?php

  $x = 3;
  $y = 2;

  function sum($a, $b)
  {
    $sum = $a + $b;
    return $sum;
  }

  echo sum($x, $y);

  ?>

</body>

</html>
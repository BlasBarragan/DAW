@extends('template')

@section('title', 'List of post')

@section('content')

<h1>List of post</h1>

@endsection

@extends('template')

@section('title', 'Post tab')

@section('content')

    @isset($id)
        <h1>Post tab {{$id}}</h1>
    @else
        <h1>No id in URL</h1>
    @endisset

@endsection

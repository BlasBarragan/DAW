<html>
    <head>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
        <title>
            <?php echo $__env->yieldContent('title'); ?>
        </title>
    </head>
    <body>
        <?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    </body>
</html>
<?php /**PATH /app/resources/views/template.blade.php ENDPATH**/ ?>
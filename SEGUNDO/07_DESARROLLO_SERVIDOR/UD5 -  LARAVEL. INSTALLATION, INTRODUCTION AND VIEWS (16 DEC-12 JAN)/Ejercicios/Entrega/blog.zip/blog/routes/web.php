<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('home');
}) -> name('home');

// EXERCISE 2

Route::get('posts', function() {
    //return 'List of Posts';
    return view('posts/listing');
}) -> name('posts_list');

Route::get('posts/{id}', function($id) {
    //return "Post number $id" ;
    return view('posts/tab') -> with('id', $id);
}) ->where('id', "[0-9]+")
-> name('post_number');

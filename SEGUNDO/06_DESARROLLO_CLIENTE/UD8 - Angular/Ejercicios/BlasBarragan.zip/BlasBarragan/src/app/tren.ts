export interface Tren {
  ident: number;
  estacioorige: string;
  estaciodesti: string;
  horaeixida: string;
  horaarrivada: string;
}

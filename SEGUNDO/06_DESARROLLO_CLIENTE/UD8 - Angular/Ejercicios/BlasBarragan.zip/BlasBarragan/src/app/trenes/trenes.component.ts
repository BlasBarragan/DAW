import { Component } from '@angular/core';
import { Tren } from '../tren';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-trenes',
  imports: [CommonModule],
  templateUrl: './trenes.component.html',
  styleUrl: './trenes.component.css'
})
export class TrenesComponent {

  horarios: Tren[] = [
    { ident: 0, estacioorige: 'Silla', estaciodesti: 'Valencia', horaeixida: '01:00', horaarrivada: '01:30' },
    { ident: 1, estacioorige: 'Valencia', estaciodesti: 'Alfafar', horaeixida: '02:00', horaarrivada: '02:30' },
    { ident: 2, estacioorige: 'Alfafar', estaciodesti: 'Aldaia', horaeixida: '03:00', horaarrivada: '03:30' },
    { ident: 3, estacioorige: 'Aldaia', estaciodesti: 'Alcudia', horaeixida: '04:00', horaarrivada: '04:30' },
    { ident: 4, estacioorige: 'Alcudia', estaciodesti: 'Xativa', horaeixida: '05:00', horaarrivada: '05:30' },
    { ident: 5, estacioorige: 'Xativa', estaciodesti: 'Algemesi', horaeixida: '06:00', horaarrivada: '06:30' },
    { ident: 6, estacioorige: 'Algemesi', estaciodesti: 'Silla', horaeixida: '07:00', horaarrivada: '07:30' },
  ];

  keys = Object.keys(this.horarios[0]);
}

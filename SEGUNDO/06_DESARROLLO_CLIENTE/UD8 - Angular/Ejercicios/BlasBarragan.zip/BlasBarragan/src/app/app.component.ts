import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { TrenesComponent } from "./trenes/trenes.component";

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, CommonModule, TrenesComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  nombre = 'Blas Barragán Román';
  curso = '2º DAW - SEMI';
  modulo = 'DEWC';

  numero = 23;

}
